package testingSerialization;
import java.io.*;
class testig implements Serializable {
	int a=20;
	final transient int b=20;
	public int method(int a,int b) {
		return a+b;
	}
}
class hello implements Serializable {
	static int a=10;
	 int b=20;
	public int add(int a,int b) {
		return a+b;
	}
}
public class firstSerial {

	public static void main(String[] args) throws Exception {
			testig tg=new testig();
			hello h=new hello();
			System.out.println("Serialization started");
			FileOutputStream fs=new FileOutputStream("testig.ser");
			ObjectOutputStream os=new ObjectOutputStream(fs);
			os.writeObject(tg);
			os.writeObject(h);
			System.out.println("Serialization ended");
			System.out.println("Deserialization started");
			FileInputStream fi=new FileInputStream("testig.ser");
			ObjectInputStream oi=new ObjectInputStream(fi);
//			testig tig=(testig)oi.readObject();
//			hello h1=(hello)oi.readObject();
			Object o=oi.readObject();
			Object o1=oi.readObject();
			if(o instanceof testig) {
				testig tig=(testig)o;
				System.out.println(tig.a+" "+tig.b);
				int c=tig.method(tig.a,tig.b);
				System.out.println(c);
			}
			if(o1 instanceof hello) {
				hello h1=(hello)o1;
//				h1.a=50;
				System.out.println(h1.a+" "+h1.b);
				int b=h1.add(h1.a,h1.b);
				System.out.println(b);
			}
			
			
			
			

			
			
			
			
			
	}

}
