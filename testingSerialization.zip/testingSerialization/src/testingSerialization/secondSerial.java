package testingSerialization;

import java.io.*;

class A implements Serializable {
	int a=10;
	 A() {
		System.out.println("A CON");
	}
	public int add(int a,int b) {
		return this.a+b;
		
	}
	
}
class B extends A implements Serializable {
	int b=20;
	 B() {
		System.out.println("B CON");
	}
	public int add(int a,int b) {
		return super.a+this.b;
		
	}
	
}
class C extends A implements Serializable {
	int c=40;
	 C() {
		System.out.println("C CON");
	}
	public int add(int a,int c) {
		return super.a+this.c;
		
	}
	
}

public class secondSerial {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		A a=new A();
		A b=new B();
		A c=new C();
		FileOutputStream ois=new FileOutputStream("inheritance.ser");
		ObjectOutputStream or=new ObjectOutputStream(ois);
		or.writeObject(a);
		or.writeObject(b);
		or.writeObject(c);
		
		FileInputStream fir=new FileInputStream("inheritance.ser");
		ObjectInputStream oir=new ObjectInputStream(fir);
		Object o1=oir.readObject();
		Object o2=oir.readObject();
		Object o3=oir.readObject();
		if(o1 instanceof A) {
			A a1=(A)o1;
			int res=a1.add(0, 25);	
			System.out.println(res);
		}
		if(o2 instanceof A) {
			A b1=(A)o2;
		
			System.out.println(	b1.add(0, 0));
		}
		if(o3 instanceof A) {
			C b3=(C)o3;
			//b3.c=80;
			System.out.println(	b3.add(0, 0));
		}

	}

}

