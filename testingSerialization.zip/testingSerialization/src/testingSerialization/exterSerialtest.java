package testingSerialization;
import java.io.*;
class testing implements Externalizable {
	int a=10;
	int b=20;
	String s="HELLO";
	transient int c=30;
	int v,e;
	String f;
	public testing() {
		System.out.println("Its mandatory to add no args constructor");
	}
	public void add(int a,int b) {
		System.out.println(a+b);
	}
	public void writeExternal(ObjectOutput out) throws IOException{
		System.out.println("writing has started");
		out.writeObject(s);
		out.writeInt(a);
		out.writeInt(c);
		
	}
	@Override
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
		System.out.println("reading started");
		f=(String)in.readObject();
		e=in.readInt();
		
		 v=in.readInt();
	}
}
public class exterSerialtest {

	public static void main(String[] args) throws Exception {
		testing t=new testing();
		System.out.println("serialization started");
		FileOutputStream fos =new FileOutputStream("testing.ser");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(t);
		FileInputStream fis=new FileInputStream("testing.ser");
		ObjectInputStream ois=new ObjectInputStream(fis);
		t=(testing)ois.readObject();
		ois.close();
		oos.close();
		System.out.println(t.e+" "+t.f+" "+t.v);

	}

}
