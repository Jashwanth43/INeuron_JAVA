package testingSerialization;

import java.io.*;
class testNonserailization {
	int branchid=48858;
}
class Account extends testNonserailization implements Serializable {
	transient int id=523;
	transient String pwd="5234443";
	String name="Jashwanth";
	private void writeObject(ObjectOutputStream oos) throws Exception{
		oos.defaultWriteObject();
		String epwd=123+pwd;
		oos.writeInt(id);
		oos.writeObject(epwd);
	}
	private void readObject(ObjectInputStream ois) throws Exception {
		ois.defaultReadObject();
		id=ois.readInt();
		String epwd=(String)ois.readObject();
		pwd=epwd.substring(3);
		
		}
}
public class thirdSerial {

	public static void main(String[] args) throws IOException,ClassNotFoundException {
		Account ac=new Account();
		ac.name="Jashwanth";
		System.out.println("SERIAL STARTED");
		FileOutputStream fo=new FileOutputStream("account.ser");
		ObjectOutputStream oos=new ObjectOutputStream(fo);
		oos.writeObject(ac);
		System.out.println("SERIAL ENDED");
		FileInputStream fis=new FileInputStream("account.ser");
		ObjectInputStream ois=new ObjectInputStream(fis);
		Account o=(Account)ois.readObject();
		System.out.println(o.id+" "+o.pwd+" "+o.name+" "+o.branchid);
		

	}

}
