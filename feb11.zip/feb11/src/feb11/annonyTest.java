package feb11;
@FunctionalInterface
interface addition {
	 void add(int a,int b);
}
public class annonyTest {

	public static void main(String[] args) {
		addition a=(int c,int d)->{
			System.out.println(c+d);
		};
		a.add(10,20);
	}

}
