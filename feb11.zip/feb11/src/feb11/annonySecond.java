
package feb11;
//annonymous inner class implements interfaces
public class annonySecond {

	public static void main(String[] args) {
//		 Thread t=new Thread() {
//			 public void run() {
//				 for(int i=0;i<5;i++) {
//					 System.out.println("hello this child thread");
//				 }
//			 }
//		 };
//		 t.run();
////---------------2---------------------
//		new Thread() {
//			public void run() {
//				for(int i=0;i<5;i++) {
//				 System.out.println("hello this child thread");
//			 }
//			}
//		}.run();
//		 System.out.println("Hello this is parent thread");
//	
//=====================3=====================================
//		Runnable r=new Runnable() { //here we are not creating for Runnable interface are creating implemest class objects
//			public void run() {
//				for(int i=0;i<5;i++) {
//				 System.out.println("hello this child thread");
//				 }
//			}
//		};
//		Thread t=new Thread(r);
//		t.run();
//==========================4======================================
//		Thread t=new Thread(()-> {
//			for(int i=0;i<5;i++) {
//				 System.out.println("hello this child thread");
//				 }
//		});
//		t.run();
//==================================5================================
//		new Thread(()->{
//			for(int i=0;i<5;i++) {
//			 System.out.println("hello this child thread");
//			 }
//		}).run();
//========================checking=====================================
//		Runnable r=()->{
//			for(int i=0;i<5;i++) {
//				 System.out.println("hello this child thread");
//				 }
//		};
//		Thread t=new Thread(r);
//		t.start();
//==================================checking==========================

		
		System.out.println("Hello this is parent thread");
	}
}
