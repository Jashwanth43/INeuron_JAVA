package feb11;


public class innclasses {
//	final int y=500;
	public static void m1() {
		int x=1000;
		  class c{
			public void m2(int a,int b) {
				System.out.println(x);
				//System.out.println(y);
				System.out.println(a+b);
			}
		}
		new c().m2(10,20);
		new c().m2(80,20);
		new c().m2(90,20);
		
	}
	public static void main(String[] args) {
		new innclasses().m1();
	}

}
