package feb11;

import java.io.*;
import java.io.IOException;

public class TestingFIle {

	public static void main(String[] args) throws IOException {
//		//File t=new File("testing.txt");
//		FileWriter fw=new FileWriter("mytxt.txt");
//		fw.write(65);
//		fw.write("hello\nmy\nname is Jashwanth");
//		char ch[]= {'a','b','c'};
//		fw.write(ch);
//		fw.flush();
		//fw.close();
		BufferedWriter bw=new BufferedWriter(new FileWriter("mytxt.txt"));
		bw.write("This is a buffere wirteter");
		bw.flush();
		bw.close();
		BufferedReader br=new BufferedReader(new FileReader("mytxt.txt"));
		String s=br.readLine();
		while(s!=null) {
			System.out.println(s);
			s=br.readLine();		}
		br.close();

	}
}
