package feb11;
class popcorn {
	public void taste() {
		System.out.println("it spicy");
	}
}
public class annoy {

	public static void main(String[] args) {
//		popcorn p=new popcorn();
//		p.taste();
		//=============1--------------
//		popcorn p=new popcorn() {
//			@Override
//			public void taste() {
//				System.out.println("it sweet");
//			}
//		};
//		p.taste();
//---------------2-----------------
//	new popcorn() {
//			public void taste() {
//				System.out.println("it sour");
//			}
//		}.taste();
		//==============3=====================
		new popcorn() {
			@Override
			public void taste() {
				System.out.println("it sour parent reference");
				childMehtod();
			}
			public void childMehtod() {
				System.out.println("This is a child method direclty can't be accessed only accessed through parent clas smethod taste()");
			}
		}.taste();

}
}

