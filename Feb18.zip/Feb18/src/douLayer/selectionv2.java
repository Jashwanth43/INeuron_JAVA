package douLayer;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.rowset.JdbcRowSet;
import javax.sql.rowset.RowSetFactory;
import javax.sql.rowset.RowSetProvider;

public class selectionv2 {

	public static void main(String[] args) throws SQLException, IOException {
		RowSetFactory rsf= RowSetProvider.newFactory();
			JdbcRowSet jrs=rsf.createJdbcRowSet();
			Properties properties=new Properties();
			FileInputStream fis=new FileInputStream("C:\\Users\\jashw\\eclipse-workspace\\Feb18\\src\\testDatabase\\database.properties");
			properties.load(fis);
			fis.close();
			jrs.setUrl((String) properties.get("url"));
			//System.out.println((String) properties.get("url"));
			jrs.setUsername((String)properties.get("user"));
			jrs.setPassword((String)properties.get("pwd"));
			jrs.setCommand("Select * from account ;");
			jrs.execute();
			 while (jrs.next()) {
	                int accno = jrs.getInt("accno");
	                String name = jrs.getString("name");
	                int balance = jrs.getInt("balance");
	                String date = jrs.getString("doj");

	                // Print or process the retrieved data as needed
	                System.out.println("Account Number: " + accno);
	                System.out.println("Name: " + name);
	                System.out.println("Balance: " + balance);
	                System.out.println("Date: " + date);
	                System.out.println();
	                

	            }
			 jrs.close();
			
	}

}
