package douLayer;
import java.text.SimpleDateFormat;
import java.sql.Connection;
import java.sql.PreparedStatement;
import jdbc.util.connection.DatabaseConnection;
import java.util.Scanner;
public class insetAccount {

	public static void main(String[] args) {
			Connection connection=null;
			PreparedStatement preparedstatement=null;
			int accno;
			String name=null;
			int balance=0;
			String date=null;
			java.util.Date uDate;
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-mm-dd");
			try {
				connection =DatabaseConnection.getConnection();
				if(connection!=null) {
					 String query = "INSERT INTO account(accno, name, balance, doj) VALUES (?, ?, ?, ?)";
				preparedstatement=connection.prepareStatement(query);
				System.out.println("Please enter the Account details:");
				Scanner sc=new Scanner(System.in);
				System.out.println("Please enter Account Number:");
				accno=sc.nextInt();
				sc.nextLine();
				System.out.println("Please enter name:");   
				name=sc.nextLine();
				System.out.println("Please enter balance:");
				balance=sc.nextInt();
				sc.nextLine();
			     System.out.println("Please enter date (yyyy-mm-dd):");
				date=sc.next();
				sc.nextLine();
				uDate=sdf.parse(date);
				long l=uDate.getTime();
				java.sql.Date sDate=new java.sql.Date(l);
				preparedstatement.setInt(1,accno);
				preparedstatement.setString(2,name);
				preparedstatement.setInt(3,balance);
				preparedstatement.setDate(4,sDate);
				boolean result=preparedstatement.execute(); 
				if(result)
					{
					System.out.println("success");
					}
		
				preparedstatement.close();
				connection.close();
				}
				
			}catch(Exception e) {
				e.printStackTrace();
			}

	}

}
