package douLayer;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import jdbc.util.connection.DatabaseConnection;

public class retrieverAccount {

	public static void main(String[] args) throws FileNotFoundException, IOException, SQLException {
			Connection connection=DatabaseConnection.getConnection();
			ResultSet resultset=null;
			java.sql.Statement statement=null;
			Scanner sc=new Scanner(System.in);
			System.out.println("Please enter the accno:");
			int accno=sc.nextInt();
			try {
				if(connection!=null) {
					String query="Select * from account where accno="+accno+";";
					statement=connection.createStatement();
					resultset=statement.executeQuery(query);
					while(resultset.next()) {
						System.out.println("accno: "+resultset.getInt(1)+"name: "+resultset.getString(2)+"balance: "+resultset.getInt(3)+"Date of Joining:  "+resultset.getDate(4));
					}
					DatabaseConnection.closeConnection(resultset,statement,connection);
					
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
	}

}
