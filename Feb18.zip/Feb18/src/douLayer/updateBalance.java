package douLayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Savepoint;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import com.mysql.cj.xdevapi.Statement;

import jdbc.util.connection.DatabaseConnection;

public class updateBalance {

	public static void main(String[] args) {
		Connection connection=null;
		PreparedStatement preparedstatement=null;
		PreparedStatement preparedstatement1=null;
		PreparedStatement preparedstatement2=null;
		try {
			connection =DatabaseConnection.getConnection();
			if(connection!=null) {
				connection.setAutoCommit(false);
				
				String query="update account set balance=balance+100 where accno=523443";
				preparedstatement=connection.prepareStatement(query);
				preparedstatement.execute();
				Savepoint sp=connection.setSavepoint();
				String query1="update account set balance=balance+80000 where accno=523443";
				String query2="update account set balance=balance-5000 where accno=444444";
				
				preparedstatement1=connection.prepareStatement(query1);
				preparedstatement2 = connection.prepareStatement(query2);
				
				preparedstatement1.execute();
				preparedstatement2.execute();	
				Scanner sc=new Scanner(System.in);
				System.out.println("yes or no:");
				String s=sc.next();
				if(s.equalsIgnoreCase("yes")) {
					connection.releaseSavepoint(null);
					connection.commit();
				}
				else {
					connection.rollback(sp);
				}
				connection.commit();
				connection.close();	
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
