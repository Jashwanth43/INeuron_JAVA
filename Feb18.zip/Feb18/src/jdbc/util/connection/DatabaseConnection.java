package jdbc.util.connection;
import java.util.Properties;
import java.sql.*;
import com.mysql.cj.jdbc.MysqlConnectionPoolDataSource;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
public class DatabaseConnection {
public static Connection getConnection() throws FileNotFoundException,IOException, SQLException {
	Properties properties=new Properties();
	FileInputStream fis=new FileInputStream("C:\\Users\\jashw\\eclipse-workspace\\Feb18\\src\\testDatabase\\database.properties");
	MysqlConnectionPoolDataSource  dataSource=new MysqlConnectionPoolDataSource ();
	properties.load(fis);
	fis.close();
	dataSource.setURL((String) properties.get("url"));
	//System.out.println((String) properties.get("url"));
	dataSource.setUser((String)properties.get("user"));
	dataSource.setPassword((String)properties.get("pwd"));
	Connection connection=null;
	connection =dataSource.getConnection();
	
	return connection;
	
}
public static void closeConnection(ResultSet resultset,Statement statement,Connection connection) throws SQLException {
	if(resultset!=null) {
		resultset.close();
	}
	if(statement!=null) {
		statement.close();
	}
	if(connection!=null) {
		connection.close();
	}
}
}
