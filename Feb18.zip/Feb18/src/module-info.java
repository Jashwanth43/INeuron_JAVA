module Feb18 {
	requires java.sql;
	requires mysql.connector.j;
	requires java.sql.rowset;
}